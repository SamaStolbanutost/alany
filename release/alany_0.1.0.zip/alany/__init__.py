"""Alany"""

__version__ = "0.1.0"
__description__ = "Programming language for creating bots in AnonyGram and other programs."

from . import *