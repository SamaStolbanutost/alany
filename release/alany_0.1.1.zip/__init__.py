"""Alany"""

__version__ = "0.1.1"
__description__ = """Programming language for creating bots
                     in AnonyGram and other programs."""
